package com.example.demo.controller;

import com.example.demo.common.CommonResult;
import com.example.demo.dto.OrderParam;
import com.example.demo.mbg.model.PmsBrand;
import com.example.demo.service.impl.TtlOrderServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Api(tags="延迟订单")
@Controller
@RequestMapping("/order")
public class TtlOrderController {
    @Autowired
    TtlOrderServiceImpl ttlOrderService;
    @ApiOperation("创建延迟订单")
    @RequestMapping(value="/create",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult generateOrder(@RequestBody OrderParam orderParam) {
       return ttlOrderService.generateOrder(orderParam);
    }
}
