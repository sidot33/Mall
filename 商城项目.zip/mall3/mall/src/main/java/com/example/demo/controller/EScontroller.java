package com.example.demo.controller;

import com.example.demo.common.CommonResult;
import com.example.demo.mbg.mapper.ProductMapper;
import com.example.demo.mbg.model.PmsProduct;
import com.example.demo.service.impl.ESService;
import com.example.demo.service.impl.ESServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.util.List;
@Api(tags="搜索")
@Controller
@RequestMapping("/search")
public class EScontroller {
    @Autowired
    ESServiceImpl esService;
    @ApiOperation("添加索引")
    @RequestMapping(value="/create/{index}",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult createindex(@PathVariable String index) throws IOException {
        if(index==null) return CommonResult.fail();
        esService.createindex(index);
return CommonResult.success(index);
    }
    @ApiOperation("添加文档")
    @RequestMapping(value="/add/{index}/{id}",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult adddocument(@PathVariable String index,@PathVariable int id) throws IOException {
        if(index==null) return CommonResult.fail();
        esService.adddocument(index,id);
        return CommonResult.success(id,"文档创建成功");
    }
    @ApiOperation("查询文档")
    @RequestMapping(value="/get/{index}/{id}",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult<String> getdocument(@PathVariable String index,@PathVariable int id) throws IOException {
        if(index==null) return CommonResult.fail();
        String doc=esService.getdocument(index,id);
        return CommonResult.success(doc);
    }
    @ApiOperation("根据信息查找")
    @RequestMapping(value="/search/{index}/{name}/{content}",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult<String> searchdocument(@PathVariable String index,@PathVariable String name,@PathVariable String content) throws IOException {
        if(index==null) return CommonResult.fail();
        String doc=esService.searchdocument(index,name,content);
        return CommonResult.success(doc);
    }
}
