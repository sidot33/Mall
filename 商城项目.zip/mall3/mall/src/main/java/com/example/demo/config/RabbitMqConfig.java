package com.example.demo.config;
import com.example.demo.common.QueueEnum;
import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMqConfig {
    @Bean
    DirectExchange orderExchange() {//消费路由
        return new DirectExchange(QueueEnum.Queue_cancel.getExchange());
    }
    @Bean
    DirectExchange delayExchange() {//给死信队列的路由
        return new DirectExchange(QueueEnum.Queue_cancelttl.getExchange());
    }
    @Bean
    public Queue orderQueue() {
        return new Queue(QueueEnum.Queue_cancel.getName());
    }
    @Bean
    public Queue orderttlQueue() {
        return QueueBuilder//注册死信队列跳转的路由和队列
                .durable(QueueEnum.Queue_cancelttl.getName())
                .withArgument("x-dead-letter-exchange", QueueEnum.Queue_cancel.getExchange())//到期后转发的交换机
                .withArgument("x-dead-letter-routing-key", QueueEnum.Queue_cancel.getRoutingkey())//到期后转发的路由键
                .build();
    }
    @Bean
    Binding orderBinding(DirectExchange orderExchange, Queue orderQueue){//绑定队列到路由
        return BindingBuilder
                .bind(orderQueue)
                .to(orderExchange)
                .with(QueueEnum.Queue_cancel.getRoutingkey());
    }
    @Bean
    Binding orderttlBinding(DirectExchange delayExchange, Queue orderttlQueue){//绑定队列到路由
        return BindingBuilder
                .bind(orderttlQueue)
                .to(delayExchange)
                .with(QueueEnum.Queue_cancelttl.getRoutingkey());
    }
}
