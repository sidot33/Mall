package com.example.demo.common;

public enum QueueEnum {
    Queue_cancel("direct","ordercancel","cancel"),
    Queue_cancelttl("ttl","delaycancel","canttl");

    String exchange;
    String name;
    String routingkey;

    QueueEnum(String exchange, String name, String routingkey) {
        this.exchange = exchange;
        this.name = name;
        this.routingkey = routingkey;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoutingkey() {
        return routingkey;
    }

    public void setRoutingkey(String routingkey) {
        this.routingkey = routingkey;
    }
}
