package com.example.demo.mbg.mapper;

import com.example.demo.mbg.model.Umspermission;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface UmsAdminRoleRelationDao {
    List<Umspermission> getPermissionList(@Param("id") Long id);
}
