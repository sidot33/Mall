package com.example.demo;

import com.example.demo.common.JwtTokenUtil;
import com.example.demo.componenet.CancelOrderSender;
import com.example.demo.mbg.mapper.*;
import com.example.demo.service.impl.*;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackageClasses = {CancelOrderSender.class,TtlOrderServiceImpl.class,MemberHistoryServiceImpl.class,ESServiceImpl.class,ProductMapper.class,PmsMapper.class, PmsBrandServiceImpl.class, RedisServiceImpl.class, UmsMemberServiceImpl.class, UmsadminMapper.class, UmsadminpermissionrelationMapper.class, UmsadminrolerelationMapper.class, UmspermissionMapper.class,UmsroleMapper.class,UmsrolepermissionrelationMapper.class,UmsAdminRoleRelationDao.class, UmsAdminServiceImpl.class, JwtTokenUtil.class})
public class DemoApplication {

    public static void main(String[] args) {


         SpringApplication.run(DemoApplication.class, args);


    }

}
