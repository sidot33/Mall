package com.example.demo.controller;

import com.example.demo.common.CommonResult;
import com.example.demo.dto.UmsAdminLoginParam;
import com.example.demo.mbg.model.Umsadmin;
import com.example.demo.mbg.model.Umspermission;
import com.example.demo.service.impl.UmsAdminService;
import com.example.demo.service.impl.UmsAdminServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Api(tags="注册登录")
@Controller
@RequestMapping("/admin")
public class UmsAdminController {
    @Autowired
    private UmsAdminServiceImpl adminService;
    @Value("${jwt.tokenHeader}")
    private String tokenHeader;
    @Value("${jwt.tokenHead}")
    private String tokenHead;

    @ApiOperation(value = "注册")
    @RequestMapping(value="/register",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult<Umsadmin> register(@RequestBody Umsadmin admin){
        Umsadmin newadmin=adminService.register(admin);
        if(newadmin==null) return CommonResult.fail();
        return CommonResult.success(newadmin);

    }

    @ApiOperation(value = "登陆")
@RequestMapping(value="/login",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult login(@RequestBody UmsAdminLoginParam param){
        String token=adminService.login(param.getUsername(), param.getPassword());
        if (token == null) {
            return CommonResult.validatedfail("用户名或密码错误");
        }
        HashMap<String, String> Map = new HashMap<>();
        Map.put("token", token);
        Map.put("tokenHead", tokenHead);
        Map.put("tokenHeader",tokenHeader);
        return CommonResult.success(Map);
    }

    @ApiOperation(value = "获取权限")
    @RequestMapping("/permission/{adminId}")
    @ResponseBody
    public CommonResult<List<Umspermission>> getPermissionList(@PathVariable Long adminId) {
        List<Umspermission> permissionList = adminService.getPermissionList(adminId);
        return CommonResult.success(permissionList);
    }
}
