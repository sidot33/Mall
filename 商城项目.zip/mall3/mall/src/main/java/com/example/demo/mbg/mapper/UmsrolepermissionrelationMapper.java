package com.example.demo.mbg.mapper;

import com.example.demo.mbg.model.Umsrolepermissionrelation;
import com.example.demo.mbg.model.UmsrolepermissionrelationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UmsrolepermissionrelationMapper {
    long countByExample(UmsrolepermissionrelationExample example);

    int deleteByExample(UmsrolepermissionrelationExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Umsrolepermissionrelation record);

    int insertSelective(Umsrolepermissionrelation record);

    List<Umsrolepermissionrelation> selectByExample(UmsrolepermissionrelationExample example);

    Umsrolepermissionrelation selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Umsrolepermissionrelation record, @Param("example") UmsrolepermissionrelationExample example);

    int updateByExample(@Param("record") Umsrolepermissionrelation record, @Param("example") UmsrolepermissionrelationExample example);

    int updateByPrimaryKeySelective(Umsrolepermissionrelation record);

    int updateByPrimaryKey(Umsrolepermissionrelation record);
}