package com.example.demo.mbg.mapper;

import com.example.demo.mbg.model.PmsProduct;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface ProductMapper {
    List<PmsProduct> getproductbyid(@Param("id") int id);
}
