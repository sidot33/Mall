package com.example.demo.componenet;

import com.example.demo.common.QueueEnum;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CancelOrderSender {

    @Autowired
    private AmqpTemplate amqpTemplate;
public void sendMessage(Long orderid,long delaytime){
    amqpTemplate.convertAndSend(QueueEnum.Queue_cancelttl.getExchange(),QueueEnum.Queue_cancelttl.getRoutingkey(),orderid,new ExpirationMessagePostProcessor(delaytime));

}
}
