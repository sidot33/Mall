package com.example.demo.common;
import com.example.demo.common.ResultCode;
public class CommonResult<T> {
    private String code;
    private String message;
    private T data;


    protected CommonResult(String code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    protected CommonResult() {
    }

    public static <T> CommonResult<T> success(T data) {
        return new CommonResult<T>(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMessage(),data);
    }
    public static <T> CommonResult<T> success(T data,String message) {
        return new CommonResult<T>(ResultCode.SUCCESS.getCode(),message,data);
    }
    public static <T> CommonResult<T> fail(String message) {
        return new CommonResult<T>(ResultCode.FAIL.getCode(),message,null);
    }
    public static <T> CommonResult<T> fail() {
        return new CommonResult<T>(ResultCode.FAIL.getCode(),ResultCode.FAIL.getMessage(),null);
    }
    public static <T> CommonResult<T> validatedfail(String message) {
        return new CommonResult<T>(ResultCode.VALIDATED_FAIL.getCode(),message,null);
    }
    public static <T> CommonResult<T> validatedfail() {
        return new CommonResult<T>(ResultCode.VALIDATED_FAIL.getCode(),ResultCode.VALIDATED_FAIL.getMessage(),null);
    }
    public static <T> CommonResult<T> unauthorized(T data) {
        return new CommonResult<T>(ResultCode.UNAUTHORIZED.getCode(),ResultCode.UNAUTHORIZED.getMessage(),data);
    }
    public static <T> CommonResult<T> forbidden(T data) {
        return new CommonResult<T>(ResultCode.FORBIDDEN.getCode(),ResultCode.FORBIDDEN.getMessage(),data);
    }
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}