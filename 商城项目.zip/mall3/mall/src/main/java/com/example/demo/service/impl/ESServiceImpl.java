package com.example.demo.service.impl;

import com.alibaba.fastjson.JSON;
import com.example.demo.mbg.mapper.ProductMapper;
import com.example.demo.mbg.model.PmsProduct;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.MatchAllQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Component
public class ESServiceImpl implements ESService{
@Autowired
   private RestHighLevelClient restHighLevelClient;
    @Autowired
    ProductMapper mapper;
    @Override
    public void createindex(String index) throws IOException {
        CreateIndexRequest request=new CreateIndexRequest(index);
        restHighLevelClient.indices().create(request, RequestOptions.DEFAULT);
    }

    @Override
    public void adddocument(String index, int id) throws IOException {
        List<PmsProduct> product=mapper.getproductbyid(id);
        PmsProduct pmsProduct=product.get(0);
        IndexRequest request=new IndexRequest(index);
        request.id(String.valueOf(id));
        request.timeout(TimeValue.MAX_VALUE);
        request.source(JSON.toJSONString(pmsProduct), XContentType.JSON);
        restHighLevelClient.index(request,RequestOptions.DEFAULT);
    }

    @Override
    public String getdocument(String index, int id) throws IOException {
        GetRequest getRequest= new GetRequest(index,String.valueOf(id));
        GetResponse getResponse=restHighLevelClient.get(getRequest,RequestOptions.DEFAULT);
        return getResponse.getSourceAsString();
    }

    @Override
    public String searchdocument(String index, String name,String content) throws IOException{
        SearchRequest searchRequest=new SearchRequest(index);
        SearchSourceBuilder searchSourceBuilder=new SearchSourceBuilder();
        TermQueryBuilder termQueryBuilder=QueryBuilders.termQuery(name,content);
        searchSourceBuilder.query(termQueryBuilder);
        searchSourceBuilder.timeout(new TimeValue(60, TimeUnit.SECONDS));
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse=restHighLevelClient.search(searchRequest,RequestOptions.DEFAULT);
        SearchHits hit=searchResponse.getHits();
        StringBuilder builder=new StringBuilder();
        for(SearchHit hit1:hit){
        builder.append(hit1.getSourceAsString());
            builder.append(" ");
        }
        return builder.toString();
    }
}
