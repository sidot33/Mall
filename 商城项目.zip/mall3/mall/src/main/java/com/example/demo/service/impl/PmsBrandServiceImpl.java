package com.example.demo.service.impl;

import com.example.demo.mbg.mapper.PmsMapper;
import com.example.demo.mbg.model.PmsBrand;
import com.example.demo.mbg.model.PmsBrandExample;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;
//适配器为PmsBrandMapper重写
@Component
public class PmsBrandServiceImpl implements PmsBrandService{
    public int getAa() {
        return aa;
    }

    public void setAa(int aa) {
        this.aa = aa;
    }
    @Autowired
    @Qualifier("pmsMapper")
    private PmsMapper mapper;

    public int aa=1;
    public PmsBrandServiceImpl() {

    }

    public PmsBrandServiceImpl(PmsMapper mapper) {
        this.mapper = mapper;
    }

    public PmsMapper getMapper() {
        return mapper;
    }

    public void setMapper(PmsMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public List<PmsBrand> listAllBrand() {
        return mapper.selectByExample(new PmsBrandExample());
    }

    @Override
    public int creatBrand(PmsBrand brand) {
        return mapper.insertSelective(brand);
    }

    @Override
    public int updateBrand(long id, PmsBrand brand) {
        brand.setId(id);//先修改id，对应上
        return mapper.updateByPrimaryKeySelective(brand);
    }

    @Override
    public int deleteBrand(long id) {
        return mapper.deleteByPrimaryKey(id);
    }

    @Override
    public List<PmsBrand> listBrand(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum,pageSize);//设置分页
        return mapper.selectByExample(new PmsBrandExample());
    }

    @Override
    public PmsBrand getBrand(long id) {
        return mapper.selectByPrimaryKey( id);
    }
}
