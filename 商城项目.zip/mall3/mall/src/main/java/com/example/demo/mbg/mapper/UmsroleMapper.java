package com.example.demo.mbg.mapper;

import com.example.demo.mbg.model.Umsrole;
import com.example.demo.mbg.model.UmsroleExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UmsroleMapper {
    long countByExample(UmsroleExample example);

    int deleteByExample(UmsroleExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Umsrole record);

    int insertSelective(Umsrole record);

    List<Umsrole> selectByExample(UmsroleExample example);

    Umsrole selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Umsrole record, @Param("example") UmsroleExample example);

    int updateByExample(@Param("record") Umsrole record, @Param("example") UmsroleExample example);

    int updateByPrimaryKeySelective(Umsrole record);

    int updateByPrimaryKey(Umsrole record);
}