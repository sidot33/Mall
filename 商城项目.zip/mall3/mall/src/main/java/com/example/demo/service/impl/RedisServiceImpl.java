package com.example.demo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;
@Component
public class RedisServiceImpl implements RedisService{
    @Autowired
private StringRedisTemplate temp;

    public RedisServiceImpl() {
    }

    public RedisServiceImpl(StringRedisTemplate temp) {
        this.temp = temp;
    }

    public StringRedisTemplate getTemp() {
        return temp;
    }

    public void setTemp(StringRedisTemplate temp) {
        this.temp = temp;
    }

    @Override
    public void set(String key, String value) {
        temp.opsForValue().set(key,value);
    }

    @Override
    public String get(String key) {
        return temp.opsForValue().get(key);
    }

    @Override
    public Boolean expire(String key, long expire) {
        return temp.expire(key,expire, TimeUnit.SECONDS);
    }

    @Override
    public void remove(String key) {
     temp.delete(key);
    }
}
