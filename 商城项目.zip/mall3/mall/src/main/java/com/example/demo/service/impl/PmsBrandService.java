package com.example.demo.service.impl;

import com.example.demo.mbg.model.PmsBrand;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;
@Mapper
public interface PmsBrandService {
    List<PmsBrand> listAllBrand();
    int creatBrand(PmsBrand brand);
    int updateBrand(long id,PmsBrand brand);
    int deleteBrand(long id);
    List<PmsBrand> listBrand(int pageNum,int pageSize);//分页的查询
    PmsBrand getBrand(long id);//根据id 获取brand
}
