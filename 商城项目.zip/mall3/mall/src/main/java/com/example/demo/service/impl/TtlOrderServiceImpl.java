package com.example.demo.service.impl;

import com.example.demo.common.CommonResult;
import com.example.demo.componenet.CancelOrderSender;
import com.example.demo.dto.OrderParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TtlOrderServiceImpl implements TtlOrderService{
    private  static Logger logger= LoggerFactory.getLogger(TtlOrderServiceImpl.class);
    @Autowired
    CancelOrderSender cancelOrderSender;
    @Override
    public CommonResult generateOrder(OrderParam orderParam) {
        long delay=30*1000;
        logger.info("generate order");
        long orderid=orderParam.getCouponId()+orderParam.getMemberReceiveAddressId();
        cancelOrderSender.sendMessage(orderid,delay);
        return CommonResult.success(orderid,"下单成功");

    }
}
