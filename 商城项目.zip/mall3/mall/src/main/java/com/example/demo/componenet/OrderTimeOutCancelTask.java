package com.example.demo.componenet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class OrderTimeOutCancelTask {
    private Logger logger= LoggerFactory.getLogger(OrderTimeOutCancelTask.class);
    @Scheduled(cron="0 0/30 * * * ? ")
    private void cancelorder(){
        logger.info("取消订单");

    }

}
