package com.example.demo.mbg.model;

import java.io.Serializable;

public class PmsProduct implements Serializable {//因为用的是high-level clent而不是respository，所有不是用注解形式输入
    private Integer id;
    private Integer brandid;
    private String brandname;
    private String name;
    private String subtitle;
    private long price;
    private Integer sale;
    private static final long serialVersionUID = 1L;

    public PmsProduct() {
    }

    public PmsProduct(Integer id, Integer brandid, String brandname, String name, String subtitle, long price, Integer sale) {
        this.id = id;
        this.brandid = brandid;
        this.brandname = brandname;
        this.name = name;
        this.subtitle = subtitle;
        this.price = price;
        this.sale = sale;
    }

    @Override
    public String toString() {
        return "PmsProduct{" +
                "id=" + id +
                ", brandid=" + brandid +
                ", brandname='" + brandname + '\'' +
                ", name='" + name + '\'' +
                ", subtitle='" + subtitle + '\'' +
                ", price=" + price +
                ", sale=" + sale +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBrandid() {
        return brandid;
    }

    public void setBrandid(Integer brandid) {
        this.brandid = brandid;
    }

    public String getBrandname() {
        return brandname;
    }

    public void setBrandname(String brandname) {
        this.brandname = brandname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public Integer getSale() {
        return sale;
    }

    public void setSale(Integer sale) {
        this.sale = sale;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
}
