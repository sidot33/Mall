package com.example.demo.controller;

import com.example.demo.common.CommonResult;
import com.example.demo.service.impl.UmsMemberServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Api(tags="验证码")
@Controller
@RequestMapping("/sso")
public class UmsMemberController {
    @Autowired
    private UmsMemberServiceImpl service;

    @ApiOperation(value = "获取验证码")
    @RequestMapping("/getAuthCode/{telephone}")
    @ResponseBody
    public CommonResult getAuthCode(@PathVariable(value = "telephone") String telephone){
        return service.generateAuthCode(telephone);
    }
    @ApiOperation(value = "验证验证码")
    @RequestMapping("/verify")
    @ResponseBody
    public CommonResult verifyAuthCode(String telephone,String AuthCode){
        return service.verifyAuthCode(telephone,AuthCode);
    }
}
