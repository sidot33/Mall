package com.example.demo.controller;

import com.example.demo.common.CommonPage;
import com.example.demo.common.CommonResult;
import com.example.demo.mbg.model.PmsBrand;
import com.example.demo.service.impl.PmsBrandService;
import com.example.demo.service.impl.PmsBrandServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
@Api(tags="查询")
@Controller
@RequestMapping("/brand")
public class PmsBrandController {

   @Autowired
    private PmsBrandServiceImpl service ;
    private static Logger logger = LoggerFactory.getLogger(PmsBrandController.class);
    @ApiOperation("查询所有品牌")
    @RequestMapping("/listAll")
    @ResponseBody
    public CommonResult<List<PmsBrand>> getBrandList() {
        return CommonResult.success(service.listAllBrand());
    }
    @ApiOperation("创建一个品牌")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult create(@RequestBody PmsBrand pmsbrand) {
        CommonResult commonresult;
        int result;
        result = service.creatBrand(pmsbrand);
        if (result == 1) {
            commonresult = CommonResult.success(pmsbrand);
            logger.debug("加入品牌成功", pmsbrand);
        } else {
            commonresult = CommonResult.fail("加入品牌失败");
            logger.debug("加入品牌失败", pmsbrand);
        }
        return commonresult;
    }
    @ApiOperation("更改品牌信息")
    @RequestMapping(value = "/update/{id}", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult updatebrand(@RequestBody PmsBrand pmsbrand, @PathVariable("id") long id) {
        CommonResult commonresult;
        int result;
        result = service.updateBrand(id, pmsbrand);
        if (result == 1) {
            commonresult = CommonResult.success(pmsbrand);
            logger.debug("修改品牌成功", pmsbrand);
        } else {
            commonresult = CommonResult.fail("修改品牌失败");
            logger.debug("修改品牌失败", pmsbrand);
        }
        return commonresult;
    }
    @ApiOperation("删除品牌信息")
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    @ResponseBody
    public CommonResult deletebrand(@PathVariable("id") long id) {
        CommonResult commonresult;
        int result;
        result = service.deleteBrand(id);
        if (result == 1) {
            commonresult = CommonResult.success(id);
            logger.debug("删除品牌成功", id);
        } else {
            commonresult = CommonResult.fail("删除品牌失败");
            logger.debug("删除品牌失败", id);
        }
        return commonresult;
    }
    @ApiOperation("分页查询")
    @RequestMapping("/list")
    @ResponseBody
    public CommonResult<CommonPage<PmsBrand>> getList(int pageNum, int pagesize) {

        List<PmsBrand> a = service.listBrand(pageNum, pagesize);
        return CommonResult.success(CommonPage.restPage(a));
    }
    @ApiOperation("按id查询")
    @RequestMapping("/{id}")
    @ResponseBody
    public CommonResult<PmsBrand> brand(@PathVariable("id") long id) {
        return CommonResult.success(service.getBrand(id));


    }
}