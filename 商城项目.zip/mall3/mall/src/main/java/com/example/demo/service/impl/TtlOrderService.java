package com.example.demo.service.impl;

import com.example.demo.common.CommonResult;
import com.example.demo.dto.OrderParam;
import org.springframework.transaction.annotation.Transactional;

public interface TtlOrderService {
    @Transactional
    CommonResult generateOrder(OrderParam orderParam);
}
