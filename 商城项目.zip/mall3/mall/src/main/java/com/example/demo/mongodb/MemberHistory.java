package com.example.demo.mongodb;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection="mall-port")
public class MemberHistory {
    @Id
    private String id;
    private Long memberid;
    private String membername;
    private Long productid;
    private String productname;
    private Date createtime;

    @Override
    public String toString() {
        return "MemberHistory{" +
                "id='" + id + '\'' +
                ", memberid=" + memberid +
                ", membername='" + membername + '\'' +
                ", productid=" + productid +
                ", productname='" + productname + '\'' +
                ", createtime=" + createtime +
                '}';
    }

    public MemberHistory() {
    }

    public MemberHistory(String id, Long memberid, String membername, Long productid, String productname, Date createtime) {
        this.id = id;
        this.memberid = memberid;
        this.membername = membername;
        this.productid = productid;
        this.productname = productname;
        this.createtime = createtime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getMemberid() {
        return memberid;
    }

    public void setMemberid(Long memberid) {
        this.memberid = memberid;
    }

    public String getMembername() {
        return membername;
    }

    public void setMembername(String membername) {
        this.membername = membername;
    }

    public Long getProductid() {
        return productid;
    }

    public void setProductid(Long productid) {
        this.productid = productid;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }
}
