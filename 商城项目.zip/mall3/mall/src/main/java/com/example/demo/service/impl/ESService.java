package com.example.demo.service.impl;

import java.io.IOException;

public interface ESService {
    void createindex(String index) throws IOException;
    void adddocument(String index, int id) throws IOException;
    String getdocument(String index, int id)throws IOException;
    String searchdocument(String index,String name,String content) throws IOException;
}
