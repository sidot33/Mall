package com.example.demo.common;

import com.power.common.constants.BaseErrorCode;

public enum ResultCode implements BaseErrorCode {
    SUCCESS("200", "操作成功"),
    FAIL("500", "操作失败"),
    VALIDATED_FAIL("1002", "验证失败"),
    UNAUTHORIZED("9999", "登陆错误"),
    FORBIDDEN("403","找不到资源");


    private String code;
    private String message;

    private ResultCode(String errCode, String errMsg) {
        this.code = errCode;
        this.message = errMsg;
    }

    public String getCode() {
        return this.code;
    }

    public String getMessage() {
        return this.message;
    }
}
