package com.example.demo.service.impl;

import com.example.demo.mbg.model.Umsadmin;
import com.example.demo.mbg.model.Umspermission;

import java.util.List;

public interface UmsAdminService {
    Umsadmin getAdminByUsername(String username);
    Umsadmin register(Umsadmin umsAdmin);
    String login(String username,String password);
    List<Umspermission> getPermissionList(long adminId);
}
