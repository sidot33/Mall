package com.example.demo.mbg.mapper;

import com.example.demo.mbg.model.Umsadmin;
import com.example.demo.mbg.model.UmsadminExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UmsadminMapper {
    long countByExample(UmsadminExample example);

    int deleteByExample(UmsadminExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Umsadmin record);

    int insertSelective(Umsadmin record);

    List<Umsadmin> selectByExample(UmsadminExample example);

    Umsadmin selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Umsadmin record, @Param("example") UmsadminExample example);

    int updateByExample(@Param("record") Umsadmin record, @Param("example") UmsadminExample example);

    int updateByPrimaryKeySelective(Umsadmin record);

    int updateByPrimaryKey(Umsadmin record);
}