package com.example.demo.service.impl;

import com.example.demo.common.CommonResult;
import com.power.common.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component
public class UmsMemberServiceImpl implements UmsMemberService{
    public UmsMemberServiceImpl(RedisServiceImpl service, String prefixcode, long expirecode) {
        this.service = service;
        this.prefixcode = prefixcode;
        this.expirecode = expirecode;
    }

    public UmsMemberServiceImpl() {
    }

    public RedisServiceImpl getService() {
        return service;
    }

    public void setService(RedisServiceImpl service) {
        this.service = service;
    }

    public String getPrefixcode() {
        return prefixcode;
    }

    public void setPrefixcode(String prefixcode) {
        this.prefixcode = prefixcode;
    }

    public long getExpirecode() {
        return expirecode;
    }

    public void setExpirecode(long expirecode) {
        this.expirecode = expirecode;
    }

    @Autowired
    private RedisServiceImpl service;
    @Value("${redis.key.prefix.authCode}")
    private String  prefixcode;
    @Value("${redis.key.expire.authCode}")
    private Long expirecode;
    @Override
    public CommonResult generateAuthCode(String telephone) {//用stringbuild做一个循环，append nextint的值
        StringBuilder a=new StringBuilder();
        Random random=new Random();
        for(int i=0;i<6;i++){
            a.append(random.nextInt());
        }
        service.set(prefixcode+telephone,a.toString());//在redis中保存telephone与二维码,tostring从builder转string
        service.expire(prefixcode+telephone,expirecode);//设置验证码数据过期时间
        return CommonResult.success(a.toString(),"验证码已获取");
    }

    @Override
    public CommonResult verifyAuthCode(String telephone, String authCode) {
        if(StringUtil.isEmpty(authCode)){
            return CommonResult.fail("请输入验证码");
        }
        String code=service.get(prefixcode+telephone);
        if(code.equals(authCode)){//比较验证码
            return CommonResult.success("验证成功");

        }
        else{
            return CommonResult.fail("验证码错误");
        }
    }
}
