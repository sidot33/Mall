package com.example.demo.mbg.mapper;

import com.example.demo.mbg.model.Umspermission;
import com.example.demo.mbg.model.UmspermissionExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UmspermissionMapper {
    long countByExample(UmspermissionExample example);

    int deleteByExample(UmspermissionExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Umspermission record);

    int insertSelective(Umspermission record);

    List<Umspermission> selectByExample(UmspermissionExample example);

    Umspermission selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Umspermission record, @Param("example") UmspermissionExample example);

    int updateByExample(@Param("record") Umspermission record, @Param("example") UmspermissionExample example);

    int updateByPrimaryKeySelective(Umspermission record);

    int updateByPrimaryKey(Umspermission record);
}