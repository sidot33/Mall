package com.example.demo.service.impl;

import com.example.demo.mongodb.MemberHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
@Component
public class MemberHistoryServiceImpl implements MemberHistoryService {

    @Autowired
    MongoTemplate mongoTemplate;
    @Override
    public int createHistory(MemberHistory memberHistory) {
        memberHistory.setId(null);//自动创建id
        memberHistory.setCreatetime(new Date());
       mongoTemplate.save(memberHistory);
        return 1;
    }

    @Override
    public int deleteHistory(String id) {
        mongoTemplate.remove(id);
        return 1;
    }

    @Override
    public List<MemberHistory> queryall() {
        return mongoTemplate.findAll(MemberHistory.class);
    }

    @Override
    public List<MemberHistory> query(String name,Object a) {
        Query query=Query.query(Criteria.where(name).is(a));
        return mongoTemplate.find(query,MemberHistory.class);
    }

}
