package com.example.demo.componenet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
@RabbitListener(queuesToDeclare = @Queue("ordercancel"))
public class CancelOrderReceiver {
    private static Logger logger= LoggerFactory.getLogger(CancelOrderReceiver.class);
    @RabbitListener
    public void handle(long oderid){
        logger.info("receive delay message",oderid);
    }
}
