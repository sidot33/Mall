package com.example.demo.mbg.mapper;

import com.example.demo.mbg.model.Umsadminpermissionrelation;
import com.example.demo.mbg.model.UmsadminpermissionrelationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UmsadminpermissionrelationMapper {
    long countByExample(UmsadminpermissionrelationExample example);

    int deleteByExample(UmsadminpermissionrelationExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Umsadminpermissionrelation record);

    int insertSelective(Umsadminpermissionrelation record);

    List<Umsadminpermissionrelation> selectByExample(UmsadminpermissionrelationExample example);

    Umsadminpermissionrelation selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Umsadminpermissionrelation record, @Param("example") UmsadminpermissionrelationExample example);

    int updateByExample(@Param("record") Umsadminpermissionrelation record, @Param("example") UmsadminpermissionrelationExample example);

    int updateByPrimaryKeySelective(Umsadminpermissionrelation record);

    int updateByPrimaryKey(Umsadminpermissionrelation record);
}