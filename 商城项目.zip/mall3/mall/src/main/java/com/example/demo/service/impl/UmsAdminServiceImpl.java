package com.example.demo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.example.demo.common.JwtTokenUtil;
import com.example.demo.mbg.mapper.UmsAdminRoleRelationDao;
import com.example.demo.mbg.mapper.UmsadminMapper;
import com.example.demo.mbg.model.Umsadmin;
import com.example.demo.mbg.model.UmsadminExample;
import com.example.demo.mbg.model.Umspermission;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Component
public class UmsAdminServiceImpl implements UmsAdminService {
    private static final Logger LOGGER = LoggerFactory.getLogger(UmsAdminServiceImpl.class);

    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Value("${jwt.tokenHead}")
    private String tokenHead;
    @Autowired
    private UmsadminMapper adminMapper;
    @Autowired
    private UmsAdminRoleRelationDao umsAdminRoleRelationDao;


    @Override
    public Umsadmin getAdminByUsername(String username) {
        UmsadminExample example=new UmsadminExample();
        example.createCriteria().andUsernameEqualTo(username);
        List<Umsadmin> list=adminMapper.selectByExample(example);
        if(list!=null&&list.size()>0){
            return list.get(0);
        }

        return null;
    }

    @Override
    public Umsadmin register(Umsadmin umsAdmin) {
        Umsadmin admin=new Umsadmin();
        BeanUtil.copyProperties(umsAdmin,admin);
        UmsadminExample example=new UmsadminExample();
        example.createCriteria().andUsernameEqualTo(admin.getUsername());
        List<Umsadmin> list=adminMapper.selectByExample(example);
        admin.setCreatetime(new Date());
        admin.setStatus(1);
        if(list.size()>0) return null;
        String pass=admin.getPassword();
        String newpass=passwordEncoder.encode(pass);
        admin.setPassword(newpass);
        adminMapper.insert(admin);
        return admin;
    }

    @Override
    public String login(String username, String password) {
        String token =null;
        try{
            UserDetails details=userDetailsService.loadUserByUsername(username);
            if(!passwordEncoder.matches(password, details.getPassword())){
                LOGGER.debug("密码错误");
                throw new BadCredentialsException("密码错误");
            }
            UsernamePasswordAuthenticationToken authentication=new UsernamePasswordAuthenticationToken(details,null,details.getAuthorities());
            SecurityContextHolder.getContext().setAuthentication(authentication);
            token=jwtTokenUtil.generateToken(details);
        }
        catch (AuthenticationException e){
            LOGGER.debug("登陆异常");
        }
        return token;
    }

    @Override
    public List<Umspermission> getPermissionList(long adminId) {
        return umsAdminRoleRelationDao.getPermissionList(adminId);
    }
}


