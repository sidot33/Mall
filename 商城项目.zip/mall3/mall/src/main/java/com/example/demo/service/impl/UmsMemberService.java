package com.example.demo.service.impl;

import com.example.demo.common.CommonResult;

public interface UmsMemberService {
    CommonResult generateAuthCode(String telephone);
    CommonResult verifyAuthCode(String telephone,String authCode);
}
