package com.example.demo.controller;

import com.example.demo.common.CommonResult;
import com.example.demo.mongodb.MemberHistory;
import com.example.demo.service.impl.MemberHistoryServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags="记录管理")
@Controller
@RequestMapping("/history")
public class MemberHistoryController{
    @Autowired
    private MemberHistoryServiceImpl memberHistoryService;

    @ApiOperation("创建浏览历史")
    @RequestMapping(value="/create",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult create(@RequestBody MemberHistory memberHistory){
        int i=memberHistoryService.createHistory(memberHistory);
        if(i==1) return CommonResult.success("创建成功");
        else return CommonResult.fail();
    }
    @ApiOperation("按id删除历史")
    @RequestMapping(value="/delete/{id}",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult delete(@PathVariable String id){
        int i=memberHistoryService.deleteHistory(id);
        if(i==1) return CommonResult.success("删除成功");
        else return CommonResult.fail();
    }
    @ApiOperation("查询所有浏览历史")
    @RequestMapping(value="/queryall",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult<List<MemberHistory>> queryall(){

        return CommonResult.success(memberHistoryService.queryall());
    }

    @ApiOperation("搜索指定浏览历史")
    @RequestMapping(value="/query/{name}/{content}",method= RequestMethod.POST)
    @ResponseBody
    public CommonResult<List<MemberHistory>> query(@PathVariable String name, @PathVariable Object content){
        return CommonResult.success(memberHistoryService.query(name,content));
    }
}
