package com.example.demo.mbg.mapper;

import com.example.demo.mbg.model.Umsadminrolerelation;
import com.example.demo.mbg.model.UmsadminrolerelationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UmsadminrolerelationMapper {
    long countByExample(UmsadminrolerelationExample example);

    int deleteByExample(UmsadminrolerelationExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Umsadminrolerelation record);

    int insertSelective(Umsadminrolerelation record);

    List<Umsadminrolerelation> selectByExample(UmsadminrolerelationExample example);

    Umsadminrolerelation selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Umsadminrolerelation record, @Param("example") UmsadminrolerelationExample example);

    int updateByExample(@Param("record") Umsadminrolerelation record, @Param("example") UmsadminrolerelationExample example);

    int updateByPrimaryKeySelective(Umsadminrolerelation record);

    int updateByPrimaryKey(Umsadminrolerelation record);
}