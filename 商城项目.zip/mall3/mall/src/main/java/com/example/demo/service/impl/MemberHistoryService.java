package com.example.demo.service.impl;

import com.example.demo.mongodb.MemberHistory;

import java.util.List;

public interface MemberHistoryService {
    int createHistory(MemberHistory memberHistory);
    int deleteHistory(String id);
    List<MemberHistory> queryall();
    List<MemberHistory> query(String name, Object a);
}
