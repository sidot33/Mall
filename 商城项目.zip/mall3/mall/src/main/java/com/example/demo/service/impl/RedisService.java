package com.example.demo.service.impl;

public interface RedisService {
    void set(String key,String value);
    String get(String key);
    Boolean expire(String key,long expire);
    void remove(String key);
}
