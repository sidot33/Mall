package com.example.demo;

import com.example.demo.mbg.mapper.PmsMapper;
import com.example.demo.mbg.mapper.ProductMapper;
import com.example.demo.mbg.model.PmsBrand;
import com.example.demo.mbg.model.PmsBrandExample;
import com.example.demo.mbg.model.PmsProduct;
import com.example.demo.service.impl.PmsBrandServiceImpl;
import org.junit.Test;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import javax.annotation.Resource;
import java.util.List;

@SpringBootTest
@EnableConfigurationProperties({PmsBrandServiceImpl.class})
@MapperScan(basePackages = "com.example.demo.mbg.mapper.PmsBrandServiceImpl")
@ComponentScan("com.example.demo.service.impl")
public class test {

@Autowired
    ProductMapper mapper;
@Test
    public void get(){
    List<PmsProduct> a=mapper.getproductbyid(1);

  for(PmsProduct product:a){
    System.out.println(a.toString());
    }}
}
